import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrls: ['./feladat.component.css']
})
export class FeladatComponent {

  vizsgaltSzam!: number;
  eredmenySzoveg: string = "";

  PrimE(vizsgaltErtek: number): boolean {
    let osztokSzama: number = 0;
    for (let i: number = 0; i <= vizsgaltErtek; i++) {
      if (vizsgaltErtek % i == 0) {
        osztokSzama++;
      }
    }
    if (osztokSzama == 2) {
      return true;
    }
    else {
      return false;
    }
  }

  eredmenyKiiro(): void {
    if (this.PrimE(this.vizsgaltSzam)) {
      this.eredmenySzoveg = "prim";
    }
    else {
      this.eredmenySzoveg = "NEM prím"
    }
  }


  megoldasok: string[] = [];

  EredmenyMentes() {
    if (this.PrimE(this.vizsgaltSzam)) {
      this.megoldasok.push(`Az ${this.vizsgaltSzam} prím`)
    }
    else {
      this.megoldasok.push(`Az ${this.vizsgaltSzam} NEM prím`);
    }
  }

}
