function PhErtek(vizsgaltErtek: number): string {
    if (vizsgaltErtek == 7) {
        return "semleges";
    }
    else if (vizsgaltErtek > 7) {
        return "lugos";
    }
    else if (vizsgaltErtek < 7) {
        return "savas";
    }
}