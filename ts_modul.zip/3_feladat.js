function MaganHangzokSzama(vizsgaltSzoveg) {
    var maganhangzok = ["a", "á", "e", "é", "i", "í", "u", "ú", "ű", "ü", "o", "ó", "ö", "ő"];
    var maganhangzokSzama = 0;
    for (var i = 0; i < vizsgaltSzoveg.length; i++) {
        for (var j = 0; j < maganhangzok.length; j++) {
            if (vizsgaltSzoveg[i] == maganhangzok[j]) {
                maganhangzokSzama++;
            }
        }
    }
    return maganhangzokSzama;
}
