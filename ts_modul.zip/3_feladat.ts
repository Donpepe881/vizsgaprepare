function MaganHangzokSzama(vizsgaltSzoveg: string): number {
    let maganhangzok: string[] = ["a", "á", "e", "é", "i", "í", "u", "ú", "ű", "ü", "o", "ó", "ö", "ő"];
    let maganhangzokSzama: number = 0;
    for (let i: number = 0; i < vizsgaltSzoveg.length; i++) {
        for (let j: number = 0; j < maganhangzok.length; j++) {
            if (vizsgaltSzoveg[i] == maganhangzok[j]) {
                maganhangzokSzama++;
            }
        }
    }
    return maganhangzokSzama;
}